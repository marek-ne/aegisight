
  # IT Service Risk Prediction Wireframes

  This is a code bundle for IT Service Risk Prediction Wireframes. The original project is available at https://www.figma.com/design/lL5choyL8qH669vWDDkQj8/IT-Service-Risk-Prediction-Wireframes.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  